# Jon Domingues — extensão experimental para Mihon

Este repositório contém uma primeira versão experimental da fonte Jon Domingues.

## O que esta versão tenta fazer
- Listar publicações do site.
- Pesquisar usando a busca do WordPress.
- Abrir a página de uma edição.
- Encontrar o link "Ler online".
- Transformar as imagens do leitor em páginas do Mihon.

## Limitações conhecidas
- Cada edição é representada como uma entrada com um único capítulo "Ler online".
- Os seletores HTML são heurísticos e podem precisar de ajustes.
- A primeira compilação serve para validar a estrutura; ainda não há garantia de funcionamento até testar no Mihon.
- O workflow compila usando a versão atual do repositório Keiyoushi.

## Compilar
O GitHub Actions executa a compilação ao enviar alterações para `main` ou ao iniciar manualmente o workflow.
O APK, se a compilação for concluída, ficará em Actions > execução concluída > Artifacts.
