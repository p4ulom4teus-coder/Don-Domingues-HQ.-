package eu.kanade.tachiyomi.extension.pt.jondomingues

import eu.kanade.tachiyomi.source.model.FilterList
import eu.kanade.tachiyomi.source.model.MangasPage
import eu.kanade.tachiyomi.source.model.Page
import eu.kanade.tachiyomi.source.model.SChapter
import eu.kanade.tachiyomi.source.model.SManga
import eu.kanade.tachiyomi.source.model.SMangaUpdate
import keiyoushi.annotation.Source
import keiyoushi.source.KeiSource
import keiyoushi.utils.asJsoup
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

/**
 * Experimental Mihon source for jondomingues.com.
 *
 * MVP design: each comic issue is represented as a manga entry and its
 * online-reader page is represented as one chapter.
 */
@Source
abstract class JonDomingues : KeiSource() {

    override suspend fun getPopularManga(page: Int): MangasPage = getCatalog("$baseUrl/?paged=$page")

    override suspend fun getLatestUpdates(page: Int): MangasPage = getCatalog("$baseUrl/?paged=$page")

    override suspend fun getSearchMangaList(
        page: Int,
        query: String,
        filters: FilterList,
    ): MangasPage {
        val url = baseUrl.toHttpUrl().newBuilder()
            .addQueryParameter("s", query)
            .addQueryParameter("paged", page.toString())
            .build()
        return getCatalog(url.toString())
    }

    private suspend fun getCatalog(url: String): MangasPage {
        val document = client.get(url).asJsoup()
        val cards = document.select(
            "article, .post, .type-post, .hentry",
        )

        val mangas = cards.mapNotNull { card ->
            val link = card.selectFirst(
                "h1 a[href], h2 a[href], h3 a[href], .entry-title a[href], a[rel=bookmark][href]",
            ) ?: card.selectFirst("a[href*='/']") ?: return@mapNotNull null

            val href = link.absUrl("href")
            val title = link.text().ifBlank { card.selectFirst("img")?.attr("alt").orEmpty() }
            if (href.isBlank() || title.isBlank() || href == baseUrl) return@mapNotNull null

            SManga.create().apply {
                this.title = title
                setUrlWithoutDomain(href)
                thumbnail_url = card.selectFirst("img")?.let { imageUrl(it) }
            }
        }.distinctBy { it.url }

        val hasNextPage = document.selectFirst(
            "a.next, a.next.page-numbers, .nav-links a[rel=next], a[rel=next]",
        ) != null

        return MangasPage(mangas, hasNextPage)
    }

    override suspend fun getMangaByUrl(url: HttpUrl): SManga? {
        if (url.host != baseUrl.toHttpUrl().host) return null

        return SManga.create().apply {
            setUrlWithoutDomain(url.toString())
        }
    }

    override suspend fun fetchMangaUpdate(
        manga: SManga,
        chapters: List<SChapter>,
        fetchDetails: Boolean,
        fetchChapters: Boolean,
    ): SMangaUpdate {
        val document = client.get(baseUrl + manga.url).asJsoup()

        if (fetchDetails) {
            manga.title = document.selectFirst(
                "h1.entry-title, h1.post-title, article h1, h1",
            )?.text()?.ifBlank { null } ?: manga.title

            manga.thumbnail_url = document.selectFirst(
                "meta[property=og:image]",
            )?.attr("content")?.takeIf { it.isNotBlank() }
                ?: document.selectFirst("article img, .entry-content img")?.let { imageUrl(it) }

            manga.description = document.selectFirst(
                ".entry-content, .post-content, article .content",
            )?.text()?.take(1500).orEmpty()
        }

        val chapterList = if (fetchChapters) {
            val readerLink = findReaderLink(document)
            if (readerLink == null) {
                emptyList()
            } else {
                listOf(
                    SChapter.create().apply {
                        name = "Ler online"
                        setUrlWithoutDomain(readerLink)
                    },
                )
            }
        } else {
            chapters
        }

        return SMangaUpdate(manga, chapterList)
    }

    override suspend fun getPageList(chapter: SChapter): List<Page> {
        val document = client.get(baseUrl + chapter.url).asJsoup()

        val images = document.select(
            ".entry-content img, .post-content img, .reader img, article img",
        ).mapNotNull { image ->
            imageUrl(image).takeIf { url ->
                url.startsWith("http") &&
                    url.contains("/wp-content/uploads/") &&
                    !url.contains("logo", ignoreCase = true) &&
                    !url.contains("avatar", ignoreCase = true) &&
                    !url.contains("icon", ignoreCase = true)
            }
        }.distinct()

        if (images.isEmpty()) {
            throw Exception("Não encontrei as páginas da HQ. O leitor do site pode ter mudado.")
        }

        return images.mapIndexed { index, imageUrl ->
            Page(index, imageUrl = imageUrl)
        }
    }

    private fun findReaderLink(document: Document): String? {
        val links = document.select("a[href]")
        val reader = links.firstOrNull {
            val label = it.text().lowercase()
            val href = it.absUrl("href")
            label.contains("ler online") || href.contains("/ler-")
        }
        return reader?.absUrl("href")?.takeIf { it.isNotBlank() }
    }

    private fun imageUrl(image: Element): String {
        return image.attr("abs:data-src").ifBlank {
            image.attr("abs:data-lazy-src")
        }.ifBlank {
            image.attr("abs:src")
        }.ifBlank {
            image.attr("abs:data-original")
        }.ifBlank {
            image.attr("abs:srcset").substringBefore(",").substringBefore(" ").trim()
        }
    }
}
