import io.github.keiyoushi.gradle.api.ContentWarning

plugins {
    alias(kei.plugins.extension)
}

keiyoushi {
    name = "Jon Domingues"
    versionCode = 1
    contentWarning = ContentWarning.MIXED
    libVersion = "1.6"

    source {
        name = "Jon Domingues"
        baseUrl = "https://jondomingues.com"
        lang = "pt-BR"
    }

    deeplink {
        path("/..*")
    }
}
